<!DOCTYPE html>
<html lang="en">

<head>
    <base href="/public">
    <!-- Required meta tags -->
    <?php echo $__env->make('Admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <div class="container-fluid page-body-wrapper">
            <?php echo $__env->make('Admin.nev', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-panel">
                <div class="content-wrapper">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>

                    <div class="container">
                    <div class="overflow-auto overflow-x-auto">
                        <h1>Edit Education</h1>
                        <form action="<?php echo e(route('update_education_conform', ['id' => $educationData->id])); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="degree" class="form-label">Degree</label>
                                <input type="text" class="form-control" id="degree" name="degree"
                                    value="<?php echo e($educationData->degree); ?>" style="color: white;" required>
                            </div>
                            <div class="mb-3">
                                <label for="duration" class="form-label">Duration</label>
                                <input type="text" class="form-control" id="duration" name="duration"
                                    value="<?php echo e($educationData->duration); ?>" style="color: white;" required>
                            </div>
                            <div class="mb-3">
                                <label for="school" class="form-label">School</label>
                                <input type="text" class="form-control" id="school" name="school"
                                    value="<?php echo e($educationData->school); ?>" style="color: white;" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="4"
                                style="color: white;"required><?php echo e($educationData->description); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Update Education</button>
                        </form>
                    </div>
                </div>
</div>
                <?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/Admin/update_eduction.blade.php ENDPATH**/ ?>