<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <?php echo $__env->make('Admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('Admin.nev', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="main-panel">

                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>


                <div class="container">
                    <h1>User Profiles</h1>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered custom-table">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Birthday</th>
                                    <th>Website</th>
                                    <th>Phone</th>
                                    <th>City</th>
                                    <th>Age</th>
                                    <th>Degree</th>
                                    <th>Freelance</th>
                                    <th>Description</th>
                                    <th>Profile Photo</th>
                                    <th>Action</th> <!-- Delete action column -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="color: white;"><?php echo e($data->id); ?></td>
                                    <td style="color: white;"><?php echo e($data->name); ?></td>
                                    <td style="color: white;"><?php echo e($data->email); ?></td>
                                    <td style="color: white;"><?php echo e($data->birthday); ?></td>
                                    <td style="color: white;"><?php echo e($data->website); ?></td>
                                    <td style="color: white;"><?php echo e($data->phone); ?></td>
                                    <td style="color: white;"><?php echo e($data->city); ?></td>
                                    <td style="color: white;"><?php echo e($data->age); ?></td>
                                    <td style="color: white;"><?php echo e($data->degree); ?></td>
                                    <td style="color: white;"><?php echo e($data->freelance); ?></td>
                                    <td style="color: white;"><?php echo e($data->description); ?></td>
                                    <td><img src="<?php echo e($data->profile_photo); ?>" alt="Profile Photo" width="100"
                                            height="100"></td>


                                    <td>
                                        <form action="<?php echo e(route('delete_profile', ['id' => $data->id])); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                    <td>
                                        <a class="btn btn-success" href="<?php echo e(route('update_profile', ['id' => $data->id])); ?>">Edit</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
        </div>
        <?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php /**PATH C:\xampp\htdocs\portfolio\resources\views/Admin/deleteprofile.blade.php ENDPATH**/ ?>