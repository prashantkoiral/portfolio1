

<p>Name: <?php echo e($data['name']); ?></p>
<p>Email: <?php echo e($data['email']); ?></p>
<p>Subject: <?php echo e($data['subject']); ?></p>
<p>Message:</p>
<p><?php echo e($data['message']); ?></p>
<?php /**PATH C:\xampp\htdocs\portfolio\resources\views/emails/contact-form.blade.php ENDPATH**/ ?>