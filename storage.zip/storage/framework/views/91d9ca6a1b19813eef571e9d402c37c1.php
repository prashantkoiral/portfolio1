<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <base href="/public">
    <?php echo $__env->make('Admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('Admin.nev', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">

                <div class="content-wrapper">

                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <div class="container">
                        <div class="overflow-auto overflow-x-auto">
                            <h1>update Professional Experience</h1>
                            <form action="<?php echo e(route('update_profession_conform', ['id' => $professionalData->id])); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="position" class="form-label">Position</label>
                                    <input type="text" class="form-control" id="position" name="position"
                                        value="<?php echo e($professionalData->position); ?>" required style="color: white;">
                                </div>

                                <div class="mb-3">
                                    <label for="duration" class="form-label">Duration</label>
                                    <input type="text" class="form-control" id="duration" name="duration"
                                        value="<?php echo e($professionalData->duration); ?>" style="color: white;" required>
                                </div>
                                <div class="mb-3">
                                    <label for="company" class="form-label">Company</label>
                                    <input type="text" class="form-control" id="company" name="company"
                                        value="<?php echo e($professionalData->company); ?>" style="color: white;" required>
                                </div>
                                <div class="mb-3">
                                    <label for="responsibilities" class="form-label">Responsibilities</label>
                                    <textarea class="form-control" id="responsibilities" name="responsibilities"
                                        rows="4" style="color: white;"
                                        required><?php echo e($professionalData->responsibilities); ?></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary">update Experience</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->

                <?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/admin/updateProfession.blade.php ENDPATH**/ ?>