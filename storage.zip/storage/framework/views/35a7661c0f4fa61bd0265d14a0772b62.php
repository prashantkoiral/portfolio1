<!DOCTYPE html>
<html lang="en">

<head>
<base href="/public">
<?php echo $__env->make('Admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <title>Edit Profile</title>


</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('Admin.nev', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">

                <div class="content-wrapper">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>

                    <div class="container">
                        <h1>Edit Profile</h1>
                        <form action="<?php echo e(url('update_profile_conform',$datas->id )); ?>" method="POST" class="row g-3"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <!-- User Information -->
                            <div class="col-md-6">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($datas->name); ?>"
                                    required style="color: white;">
                            </div>

                            <div class="col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email"
                                    value="<?php echo e($datas->email); ?>" required style="color: white;">
                            </div>
                            <div class="col-4">
                                <label for="birthday" class="form-label">Birthday</label>
                                <input type="date" class="form-control" id="birthday" name="birthday"
                                    value="<?php echo e($datas->birthday); ?>" style="color: white;">
                            </div>
                            <div class="col-8">
                                <label for="website" class="form-label">Website</label>
                                <input type="text" class="form-control" id="website" name="website"
                                    value="<?php echo e($datas->website); ?>" style="color: white;">
                            </div>
                            <div class="col-6">
                                <label for="phone" class="form-label">Phone</label>
                                <input type="text" class="form-control" id="phone" name="phone"
                                    value="<?php echo e($datas->phone); ?>" style="color: white;">
                            </div>
                            <div class="col-6">
                                <label for="city" class="form-label">City</label>
                                <input type="text" class="form-control" id="city" name="city" value="<?php echo e($datas->city); ?>"
                                    style="color: white;">
                            </div>
                            <div class="col-md-6">
                                <label for="age" class="form-label">Age</label>
                                <input type="number" class="form-control" id="age" name="age" value="<?php echo e($datas->age); ?>"
                                    style="color: white;">
                            </div>
                            <div class="col-md-6">
                                <label for="degree" class="form-label">Degree</label>
                                <input type="text" class="form-control" id="degree" name="degree"
                                    value="<?php echo e($datas->degree); ?>" style="color: white;">
                            </div>
                            <div class="col-6">
                                <label for="freelance" class="form-label">Freelance</label>
                                <input type="text" class="form-control" id="freelance" name="freelance"
                                    value="<?php echo e($datas->freelance); ?>" style="color: white;">
                            </div>
                            <div class="col-6">
                                <label for="description" class="form-label">Description</label>
                                <input type="text" class="form-control" id="description" name="description"
                                    value="<?php echo e($datas->description); ?>" style="color: white;">
                            </div>

                            <div class="col-4">
                                <label for="current_profile" class="form-label">Current Profile Picture</label>
                                <img src="storage/<?php echo e($datas->profile_photo); ?>" class="img-fluid" alt="">
                            </div>



                            <div class="col-6">
                                <label for="profile_photo" class="form-label">update Profile Photo</label>
                                <input type="file" class="form-control" id="profile_photo" name="profile_photo"
                                    style="color: white;">
                            </div>

                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">Update User Information</button>
                            </div>

                        </form>
                    </div>

                </div>
            </div>

            <!-- content-wrapper ends -->
            <!-- partial:partials/_footer.html -->

            <?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/admin/updateUser.blade.php ENDPATH**/ ?>