<footer class="footer">
<div class="d-sm-flex justify-content-center justify-content-sm-between">
    <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">
        <!-- Your copyright text here -->
        Copyright © Your Company Name 2023
    </span>
    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">
        Free <a href="https://www.your-website.com" target="_blank">Your Link Text</a>
    </span>
</div>

                    </footer>
                    <!-- partial -->
                </div>
                <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
        </div>
        <!-- container-scroller -->
        <!-- plugins:js -->
        <script src="Admin/assets/vendors/js/vendor.bundle.base.js"></script>
        <!-- endinject -->
        <!-- Plugin js for this page -->
        <script src="Admin/assets/vendors/chart.js/Chart.min.js"></script>
        <script src="Admin/assets/vendors/progressbar.js/progressbar.min.js"></script>
        <script src="Admin/assets/vendors/jvectormap/jquery-jvectormap.min.js"></script>
        <script src="Admin/assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
        <script src="Admin/assets/vendors/owl-carousel-2/owl.carousel.min.js"></script>
        <!-- End plugin js for this page -->
        <!-- inject:js -->
        <script src="Admin/assets/js/off-canvas.js"></script>
        <script src="Admin/assets/js/hoverable-collapse.js"></script>
        <script src="Admin/assets/js/misc.js"></script>
        <script src="Admin/assets/js/settings.js"></script>
        <script src="Admin/assets/js/todolist.js"></script>
        <!-- endinject -->
        <!-- Custom js for this page -->
        <script src="Admin/assets/js/dashboard.js"></script>
        <!-- End custom js for this page -->
    </body>

    </html><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/Admin/footer.blade.php ENDPATH**/ ?>