<section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
    <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1 data-aos="fade-up"><?php echo e($profile->name); ?></h1>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <p>I'm <span class="typed" data-typed-items="Developer, Freelancer, Designer, Photographer"></span></p>
    </div>
  </section><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/home/hero.blade.php ENDPATH**/ ?>