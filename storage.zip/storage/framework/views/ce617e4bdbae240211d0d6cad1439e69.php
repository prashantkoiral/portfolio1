<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <?php echo $__env->make('Admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('Admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_navbar.html -->
            <?php echo $__env->make('Admin.nev', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- partial -->
            <div class="main-panel">

                <div class="content-wrapper">
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>


<div class="container">
<div class="overflow-auto">
    <h1>Professional Experience</h1>
    <table class="table">
        <thead>
            <tr>
            <th style="color: white; font-weight: bold;">ID</th>
                <th style="color: white; font-weight: bold;">Position</th>
                <th style="color: white; font-weight: bold;">Duration</th>
                <th style="color: white; font-weight: bold;">Company</th>
                <th style="color: white; font-weight: bold;">Responsibilities</th>
                <th style="color: white; font-weight: bold;">Action</th> <!-- Delete action column -->
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $professionalData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Replace with your professional experience data variable -->
            <tr>
            <td required style="color: white;"><?php echo e($profData->id); ?></td>
                <td required style="color: white;"><?php echo e($profData->position); ?></td>
                <td required style="color: white;"><?php echo e($profData->duration); ?></td>
                <td required style="color: white;"><?php echo e($profData->company); ?></td>
                <td required style="color: white;"><?php echo e($profData->responsibilities); ?></td>
                <td>
                    <form action="<?php echo e(route('delete_professional', ['id' => $profData->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
                <td>
                <a class="btn btn-success" href="<?php echo e(route('update_profession', ['id' => $profData->id])); ?>">Edit</a>
                 </td>
             </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
</div>

<!-- content-wrapper ends -->
<!-- partial:partials/_footer.html -->

<?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/Admin/delete_professional.blade.php ENDPATH**/ ?>